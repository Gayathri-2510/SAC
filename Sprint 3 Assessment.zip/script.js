
class Task {
  constructor(id,name,description,assignedTo,dueDate,status){
    this.id=id;
    this.name=name;
    this.description=description;
    this.assignedTo=assignedTo;
    this.dueDate=dueDate;
    this.status=status;
  }
}

class TaskManager{
  constructor(){
    this.tasks=JSON.parse(localStorage.getItem("tasks"))||[];
    this.currentId=this.tasks.length?this.tasks[this.tasks.length-1].id+1:1;
  }

  save(){
    localStorage.setItem("tasks",JSON.stringify(this.tasks));
  }

  add(task){
    this.tasks.push(task);
    this.save();
  }

  delete(id){
    this.tasks=this.tasks.filter(t=>t.id!==id);
    this.save();
  }

  update(updated){
    this.tasks=this.tasks.map(t=>t.id===updated.id?updated:t);
    this.save();
  }

  assignTo(id,name){
    this.tasks.find(t=>t.id===id).assignedTo=name;
    this.save();
  }
}

const manager=new TaskManager();
let editId=null;

function render(){
  const list=document.getElementById("taskList");
  list.innerHTML="";
  manager.tasks.forEach(t=>{
    list.innerHTML+=`
    <div class="task" onclick="editTask(${t.id})">
    ${t.name} | ${t.status}<br>
    ${t.assignedTo} | ${t.dueDate}<br>
    <button onclick="remove(${t.id});event.stopPropagation()">Delete</button>
    </div>`;
  });
}

function validate(){
  if(!name.value||!description.value||!assignedTo.value||!dueDate.value||!status.value){
    error.innerText="All fields required";
    return false;
  }
  error.innerText="";
  return true;
}

function saveTask(){
 if(!validate())return;

 if(editId){
   manager.update(new Task(editId,name.value,description.value,assignedTo.value,dueDate.value,status.value));
   saveBtn.innerText="Save";
   editId=null;
 }else{
   manager.add(new Task(manager.currentId++,name.value,description.value,assignedTo.value,dueDate.value,status.value));
 }

 document.querySelectorAll("input").forEach(i=>i.value="");
 status.value="";
 render();
}

function editTask(id){
 const t=manager.tasks.find(x=>x.id===id);
 name.value=t.name;
 description.value=t.description;
 assignedTo.value=t.assignedTo;
 dueDate.value=t.dueDate;
 status.value=t.status;
 saveBtn.innerText="Update";
 editId=id;
}

function remove(id){
 manager.delete(id);
 render();
}

render();
