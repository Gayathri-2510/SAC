
console.log("Running Tests");

function assert(msg,cond){
 console.log(msg, cond?"PASS":"FAIL");
}

const tm=new TaskManager();
tm.tasks=[];

tm.add(new Task(1,"A","B","C","2026-01-01","Pending"));
assert("Add Task",tm.tasks.length===1);

tm.assignTo(1,"Sneka");
assert("Assign To",tm.tasks[0].assignedTo==="Sneka");

tm.update(new Task(1,"X","Y","Z","2026-02-02","Done"));
assert("Update Task",tm.tasks[0].name==="X");

tm.delete(1);
assert("Delete Task",tm.tasks.length===0);

document.body.innerHTML='<div id="taskList"></div>';
tm.add(new Task(2,"UI","Test","A","2026","Pending"));
render();
assert("UI Add",document.getElementById("taskList").children.length===1);

remove(2);
assert("UI Delete",document.getElementById("taskList").children.length===0);
