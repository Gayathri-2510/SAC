
package com.example.taskmanager.controller;

import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import java.util.List;
import com.example.taskmanager.service.TaskService;
import com.example.taskmanager.entity.Task;

@RestController
@RequestMapping("/api/tasks")
@CrossOrigin("*")
@RequiredArgsConstructor
public class TaskController {

private final TaskService service;

@GetMapping
public List<Task> get(){return service.all();}

@PostMapping
public Task add(@RequestBody Task t){return service.add(t);}

@DeleteMapping("/{id}")
public void delete(@PathVariable Long id){service.delete(id);}
}
