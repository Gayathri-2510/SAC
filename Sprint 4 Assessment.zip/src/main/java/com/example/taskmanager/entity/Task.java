
package com.example.taskmanager.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Data
public class Task {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private Long id;

@NotBlank
private String name;

@NotBlank
private String description;

@NotBlank
private String assignedTo;

@NotBlank
private String status;
}
