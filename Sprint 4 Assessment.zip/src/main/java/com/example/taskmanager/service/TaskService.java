
package com.example.taskmanager.service;

import java.util.List;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;
import com.example.taskmanager.repository.TaskRepository;
import com.example.taskmanager.entity.Task;

@Service
@RequiredArgsConstructor
public class TaskService {

private final TaskRepository repo;

public List<Task> all(){return repo.findAll();}
public Task add(Task t){return repo.save(t);}
public void delete(Long id){repo.deleteById(id);}
}
